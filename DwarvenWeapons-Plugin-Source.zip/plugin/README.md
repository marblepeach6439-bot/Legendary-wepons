# Dwarven Weapons (Paper 1.21.x)

Build: `mvn package` (Java 21) -> target/DwarvenWeapons-1.0.0.jar -> drop in /plugins.
Give items: `/dweapons give <player> <bloody_eclipse|stormcaller|dwarven_pickaxe|ten_ton_axe|void_blade|inferno|all>`
Resource pack: upload DwarvenWeapons-ResourcePack.zip somewhere, put the link in config.yml (`resource-pack-url`)
or in server.properties. Items use the `item_model` component -> dwarven:<weapon_id>.

Ability keys: F (offhand swap) and Shift+F, while holding the weapon in the main hand.
Passives (speed, strength, etc.) apply while the weapon is in the main hand.
Cooldowns / radii are in config.yml.
